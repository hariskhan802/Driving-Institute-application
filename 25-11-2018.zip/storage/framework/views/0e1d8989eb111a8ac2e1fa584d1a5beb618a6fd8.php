
    <!-- jQuery -->
    <script src="<?php echo e(url('public')); ?>/vendors/jquery/dist/jquery.min.js"></script>
    <!-- Bootstrap -->
    <script src="<?php echo e(url('public')); ?>/vendors/bootstrap/dist/js/bootstrap.min.js"></script>
    <!-- FastClick -->
    <script src="<?php echo e(url('public')); ?>/vendors/fastclick/lib/fastclick.js"></script>
    <!-- NProgress -->
    <script src="<?php echo e(url('public')); ?>/vendors/nprogress/nprogress.js"></script>
    <!-- Chart.js -->
    <script src="<?php echo e(url('public')); ?>/vendors/Chart.js/dist/Chart.min.js"></script>
    <!-- gauge.js -->
    <script src="<?php echo e(url('public')); ?>/vendors/gauge.js/dist/gauge.min.js"></script>
    <!-- bootstrap-progressbar -->
    <script src="<?php echo e(url('public')); ?>/vendors/bootstrap-progressbar/bootstrap-progressbar.min.js"></script>
    <!-- iCheck -->
    <script src="<?php echo e(url('public')); ?>/vendors/iCheck/icheck.min.js"></script>
    <!-- Skycons -->
    <script src="<?php echo e(url('public')); ?>/vendors/skycons/skycons.js"></script>
    <!-- Flot -->
    <script src="<?php echo e(url('public')); ?>/vendors/Flot/jquery.flot.js"></script>
    <script src="<?php echo e(url('public')); ?>/vendors/Flot/jquery.flot.pie.js"></script>
    <script src="<?php echo e(url('public')); ?>/vendors/Flot/jquery.flot.time.js"></script>
    <script src="<?php echo e(url('public')); ?>/vendors/Flot/jquery.flot.stack.js"></script>
    <script src="<?php echo e(url('public')); ?>/vendors/Flot/jquery.flot.resize.js"></script>
    <!-- Flot plugins -->
    <script src="<?php echo e(url('public')); ?>/vendors/flot.orderbars/js/jquery.flot.orderBars.js"></script>
    <script src="<?php echo e(url('public')); ?>/vendors/flot-spline/js/jquery.flot.spline.min.js"></script>
    <script src="<?php echo e(url('public')); ?>/vendors/flot.curvedlines/curvedLines.js"></script>
    <!-- DateJS -->
    <script src="<?php echo e(url('public')); ?>/vendors/DateJS/build/date.js"></script>
    <!-- JQVMap -->
    <script src="<?php echo e(url('public')); ?>/vendors/jqvmap/dist/jquery.vmap.js"></script>
    <script src="<?php echo e(url('public')); ?>/vendors/jqvmap/dist/maps/jquery.vmap.world.js"></script>
    <script src="<?php echo e(url('public')); ?>/vendors/jqvmap/examples/js/jquery.vmap.sampledata.js"></script>
    <!-- bootstrap-daterangepicker -->
    <script src="<?php echo e(url('public')); ?>/vendors/moment/min/moment.min.js"></script>
    <script src="<?php echo e(url('public')); ?>/vendors/bootstrap-daterangepicker/daterangepicker.js"></script>

    <!-- Custom Theme Scripts -->
    <script src="<?php echo e(url('public')); ?>/js/custom.min.js"></script>
    <!-- Angular File    -->
    <script src="<?php echo e(url('/public/js')); ?>/angular.min.js"></script>
    <!-- <script src="//code.angularjs.org/snapshot/angular.min.js" ></script> -->
    <script src="<?php echo e(url('/public/js')); ?>/ocLazyLoad.js"></script>

    <script src="<?php echo e(url('/public/js')); ?>/angular-ui-router.min.js"></script>
    <script src="<?php echo e(url('/frontend/js')); ?>/app.js"></script>
    <script src="<?php echo e(url('public')); ?>/js/sweet-alert/sweetalert.js"></script>
    
    <script src="<?php echo e(url('public')); ?>/vendors/jqueryui/jquery-ui.js"></script>
    <script src="<?php echo e(url('public')); ?>/js/custom.js"></script>